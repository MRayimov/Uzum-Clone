import React from "react";

const NotFound = () => {
  return (
    <div className="flex justify-center items-center h-96">
      <img
        className="w-[750px] h-96"
        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ06xA7k6bZpT2-4FlDBe8Gy3OAyDSmSnFIVQ&s"
        alt=""
      />
    </div>
  );
};

export default NotFound;
